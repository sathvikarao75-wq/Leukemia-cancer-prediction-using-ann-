import { useEffect, useRef } from "react";

// Lightweight particle + connection network background (no deps).
export function ParticleField({ density = 60 }: { density?: number }) {
  const ref = useRef<HTMLCanvasElement>(null);

  useEffect(() => {
    const canvas = ref.current;
    if (!canvas) return;
    const ctx = canvas.getContext("2d");
    if (!ctx) return;

    let w = (canvas.width = canvas.offsetWidth * devicePixelRatio);
    let h = (canvas.height = canvas.offsetHeight * devicePixelRatio);
    let raf = 0;

    const pts = Array.from({ length: density }, () => ({
      x: Math.random() * w,
      y: Math.random() * h,
      vx: (Math.random() - 0.5) * 0.3,
      vy: (Math.random() - 0.5) * 0.3,
      r: Math.random() * 1.5 + 0.5,
    }));

    const onResize = () => {
      w = canvas.width = canvas.offsetWidth * devicePixelRatio;
      h = canvas.height = canvas.offsetHeight * devicePixelRatio;
    };
    window.addEventListener("resize", onResize);

    const draw = () => {
      ctx.clearRect(0, 0, w, h);
      for (const p of pts) {
        p.x += p.vx; p.y += p.vy;
        if (p.x < 0 || p.x > w) p.vx *= -1;
        if (p.y < 0 || p.y > h) p.vy *= -1;
        ctx.fillStyle = "rgba(120, 220, 255, 0.55)";
        ctx.beginPath();
        ctx.arc(p.x, p.y, p.r * devicePixelRatio, 0, Math.PI * 2);
        ctx.fill();
      }
      for (let i = 0; i < pts.length; i++) {
        for (let j = i + 1; j < pts.length; j++) {
          const a = pts[i], b = pts[j];
          const dx = a.x - b.x, dy = a.y - b.y;
          const d = Math.hypot(dx, dy);
          const max = 130 * devicePixelRatio;
          if (d < max) {
            ctx.strokeStyle = `rgba(120, 220, 255, ${0.18 * (1 - d / max)})`;
            ctx.lineWidth = devicePixelRatio * 0.6;
            ctx.beginPath();
            ctx.moveTo(a.x, a.y);
            ctx.lineTo(b.x, b.y);
            ctx.stroke();
          }
        }
      }
      raf = requestAnimationFrame(draw);
    };
    draw();
    return () => { cancelAnimationFrame(raf); window.removeEventListener("resize", onResize); };
  }, [density]);

  return <canvas ref={ref} className="absolute inset-0 h-full w-full" aria-hidden />;
}

// 3D rotating DNA double helix using pure CSS transforms.
export function DnaHelix() {
  const pairs = 20;
  return (
    <div
      className="relative grid place-items-center"
      style={{ perspective: "1000px", width: 220, height: 320 }}
      aria-hidden
    >
      <div className="animate-dna relative h-full w-full" style={{ transformStyle: "preserve-3d" }}>
        {Array.from({ length: pairs }).map((_, i) => {
          const angle = (i / pairs) * 720;
          const y = (i / pairs) * 280 - 140;
          return (
            <div
              key={i}
              className="absolute left-1/2 top-1/2"
              style={{
                transform: `translate(-50%, ${y}px) rotateY(${angle}deg)`,
                transformStyle: "preserve-3d",
              }}
            >
              <div
                className="absolute h-2 w-2 rounded-full"
                style={{
                  background: "oklch(0.8 0.18 195)",
                  boxShadow: "0 0 12px oklch(0.8 0.18 195 / 0.9)",
                  transform: "translateX(-50px)",
                }}
              />
              <div
                className="absolute h-2 w-2 rounded-full"
                style={{
                  background: "oklch(0.7 0.22 30)",
                  boxShadow: "0 0 12px oklch(0.7 0.22 30 / 0.9)",
                  transform: "translateX(50px)",
                }}
              />
              <div
                className="absolute h-px"
                style={{
                  width: 100,
                  left: -50,
                  top: 4,
                  background: "linear-gradient(90deg, oklch(0.8 0.18 195 / 0.7), oklch(0.7 0.22 30 / 0.7))",
                }}
              />
            </div>
          );
        })}
      </div>
    </div>
  );
}

// ECG line — animated stroke, can sit at bottom of hero or header.
export function EcgLine({ className }: { className?: string }) {
  return (
    <svg viewBox="0 0 1200 80" className={className} preserveAspectRatio="none" aria-hidden>
      <path
        d="M0 40 L150 40 L170 40 L185 20 L200 60 L215 10 L230 70 L245 40 L400 40 L420 40 L435 25 L450 55 L465 15 L480 65 L495 40 L700 40 L720 40 L735 20 L750 60 L765 10 L780 70 L795 40 L1000 40 L1200 40"
        fill="none"
        stroke="oklch(0.8 0.18 195)"
        strokeWidth="2"
        className="animate-ecg"
        style={{ filter: "drop-shadow(0 0 6px oklch(0.8 0.18 195 / 0.8))" }}
      />
    </svg>
  );
}
