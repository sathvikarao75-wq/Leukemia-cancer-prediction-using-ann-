import { useEffect, useState } from "react";
import { motion, AnimatePresence } from "motion/react";
import { Link } from "@tanstack/react-router";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/hooks/use-auth";
import type { AnnInputs, AnnResult } from "@/lib/ann";

const SUBTYPES = ["ALL", "AML", "CLL", "CML", "MDS", "None"] as const;
type Subtype = (typeof SUBTYPES)[number];

interface Props {
  reportId: string;
  patientName: string;
  bloodGroup: string;
  inputs: AnnInputs;
  result: AnnResult;
  adjustedRisk: number;
  adjustedLevel: string;
}

interface RecentReview {
  id: string;
  report_id: string;
  ai_subtype: string | null;
  confirmed_subtype: string;
  agreement: boolean;
  clinician_name: string;
  created_at: string;
}

export function ClinicianReview({
  reportId, patientName, bloodGroup, inputs, result, adjustedRisk, adjustedLevel,
}: Props) {
  const { user, role, loading, isClinician } = useAuth();
  const aiSubtype = (result.subtypeHint ?? "None") as string;
  const [confirmed, setConfirmed] = useState<Subtype>(SUBTYPES.includes(aiSubtype as Subtype) ? (aiSubtype as Subtype) : "None");
  const [clinicianName, setClinicianName] = useState("");
  const [notes, setNotes] = useState("");
  const [saving, setSaving] = useState(false);
  const [saved, setSaved] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [recent, setRecent] = useState<RecentReview[]>([]);
  const [stats, setStats] = useState<{ total: number; agreement: number } | null>(null);

  useEffect(() => {
    setConfirmed(SUBTYPES.includes(aiSubtype as Subtype) ? (aiSubtype as Subtype) : "None");
    setSaved(false);
  }, [aiSubtype, reportId]);

  useEffect(() => {
    if (user?.email && !clinicianName) setClinicianName(user.email.split("@")[0]);
  }, [user]);

  const loadRecent = async () => {
    const { data } = await supabase
      .from("clinician_reviews")
      .select("id, report_id, ai_subtype, confirmed_subtype, agreement, clinician_name, created_at")
      .order("created_at", { ascending: false })
      .limit(5);
    if (data) {
      setRecent(data as RecentReview[]);
      const { data: all } = await supabase.from("clinician_reviews").select("agreement");
      if (all) {
        const total = all.length;
        const agreement = all.filter((r: any) => r.agreement).length;
        setStats({ total, agreement });
      }
    }
  };

  useEffect(() => { loadRecent(); }, []);

  const submit = async () => {
    if (!user || !isClinician) return;
    if (!clinicianName.trim()) { setError("Clinician name is required."); return; }
    setSaving(true); setError(null);
    const { error: insErr } = await supabase.from("clinician_reviews").insert({
      report_id: reportId,
      patient_name: patientName,
      patient_age: inputs.age,
      blood_group: bloodGroup,
      wbc: inputs.wbc, rbc: inputs.rbc, hemoglobin: inputs.hemoglobin,
      platelets: inputs.platelets, blast_pct: inputs.blastPct,
      ai_risk: adjustedRisk,
      ai_level: adjustedLevel,
      ai_subtype: result.subtypeHint,
      confirmed_subtype: confirmed,
      agreement: confirmed === aiSubtype,
      clinician_name: clinicianName.trim(),
      notes: notes.trim() || null,
      reviewer_id: user.id,
    });
    setSaving(false);
    if (insErr) { setError(insErr.message); return; }
    setSaved(true);
    setNotes("");
    loadRecent();
  };

  const overriding = confirmed !== aiSubtype;

  return (
    <div className="mt-6 rounded-xl border border-primary/30 bg-card/50 p-5">
      <div className="flex items-center justify-between">
        <div>
          <p className="font-mono text-[10px] uppercase tracking-widest text-primary">Clinician review</p>
          <p className="mt-1 text-sm font-semibold">Confirm or override AI subtype</p>
        </div>
        <div className="text-right font-mono text-[10px] uppercase tracking-widest text-muted-foreground">
          {user ? (
            <>
              <p className="text-foreground">{user.email}</p>
              <p className={role ? "text-primary" : "text-warning"}>
                {role ? `Role: ${role}` : "No clinician role"}
              </p>
            </>
          ) : (
            <p>Not signed in</p>
          )}
          {stats && <p className="mt-1">{stats.total} reviews · {stats.total > 0 ? Math.round((stats.agreement / stats.total) * 100) : 0}% agreement</p>}
        </div>
      </div>

      {/* Gate */}
      {loading ? (
        <p className="mt-4 font-mono text-[11px] text-muted-foreground">Checking credentials…</p>
      ) : !user ? (
        <div className="mt-4 rounded-lg border border-dashed border-primary/40 bg-primary/5 p-4">
          <p className="text-sm font-semibold">Sign in to review this report</p>
          <p className="mt-1 font-mono text-[11px] text-muted-foreground">
            Only authorised clinicians can confirm or override AI predictions.
          </p>
          <Link to="/auth" className="mt-3 inline-block rounded-lg bg-gradient-primary px-4 py-2 text-xs font-semibold text-primary-foreground shadow-glow">
            Open clinician portal
          </Link>
        </div>
      ) : !isClinician ? (
        <div className="mt-4 rounded-lg border border-warning/40 bg-warning/5 p-4">
          <p className="text-sm font-semibold text-warning">Awaiting role assignment</p>
          <p className="mt-1 font-mono text-[11px] text-muted-foreground">
            Your account doesn't yet have the <span className="text-foreground">clinician</span> or <span className="text-foreground">admin</span> role.
            Ask an administrator to grant it before you can submit reviews.
          </p>
          <button
            onClick={() => supabase.auth.signOut()}
            className="mt-3 rounded-md border border-border bg-secondary/60 px-3 py-1.5 font-mono text-[11px] uppercase tracking-widest hover:bg-secondary"
          >
            Sign out
          </button>
        </div>
      ) : (
        <>
          <div className="mt-4">
            <p className="font-mono text-[10px] uppercase tracking-widest text-muted-foreground">
              AI suggested: <span className="text-primary">{aiSubtype}</span>
            </p>
            <div className="mt-2 flex flex-wrap gap-1.5">
              {SUBTYPES.map((s) => {
                const selected = confirmed === s;
                const isAi = s === aiSubtype;
                return (
                  <button
                    key={s}
                    onClick={() => { setConfirmed(s); setSaved(false); }}
                    className={`relative rounded-md border px-3 py-1.5 font-mono text-xs transition ${
                      selected
                        ? "border-primary bg-primary/20 text-primary"
                        : "border-border bg-secondary/40 text-muted-foreground hover:text-foreground"
                    }`}
                  >
                    {s}
                    {isAi && <span className="ml-1.5 text-[9px] uppercase opacity-60">ai</span>}
                  </button>
                );
              })}
            </div>
            {overriding && (
              <p className="mt-2 font-mono text-[10px] text-warning">⚑ Overriding AI prediction</p>
            )}
          </div>

          <div className="mt-4 grid gap-3 md:grid-cols-2">
            <div>
              <label className="font-mono text-[10px] uppercase tracking-widest text-muted-foreground">Clinician name</label>
              <input
                value={clinicianName}
                onChange={(e) => { setClinicianName(e.target.value); setSaved(false); }}
                placeholder="Dr. Full Name"
                className="mt-1 w-full rounded-md border border-border bg-background/60 px-3 py-2 text-sm outline-none focus:border-primary"
              />
            </div>
            <div>
              <label className="font-mono text-[10px] uppercase tracking-widest text-muted-foreground">Notes (optional)</label>
              <input
                value={notes}
                onChange={(e) => setNotes(e.target.value)}
                placeholder="Clinical rationale, recommended follow-up…"
                className="mt-1 w-full rounded-md border border-border bg-background/60 px-3 py-2 text-sm outline-none focus:border-primary"
              />
            </div>
          </div>

          <div className="mt-4 flex items-center gap-3">
            <button
              onClick={submit}
              disabled={saving}
              className="rounded-lg bg-gradient-primary px-5 py-2.5 text-sm font-semibold text-primary-foreground shadow-glow transition disabled:opacity-60"
            >
              {saving ? "Saving…" : overriding ? "Save override" : "Confirm diagnosis"}
            </button>
            <AnimatePresence>
              {saved && (
                <motion.span
                  initial={{ opacity: 0, x: -8 }} animate={{ opacity: 1, x: 0 }} exit={{ opacity: 0 }}
                  className="font-mono text-[11px] uppercase tracking-widest text-success"
                >
                  ✓ Saved to training set
                </motion.span>
              )}
            </AnimatePresence>
            {error && <span className="font-mono text-[11px] text-destructive">{error}</span>}
          </div>
        </>
      )}

      {recent.length > 0 && (
        <div className="mt-5 border-t border-border/60 pt-4">
          <p className="font-mono text-[10px] uppercase tracking-widest text-muted-foreground">Recent reviews</p>
          <ul className="mt-2 space-y-1.5">
            {recent.map((r) => (
              <li key={r.id} className="flex items-center justify-between gap-3 font-mono text-[11px]">
                <span className="flex items-center gap-2">
                  <span className={`h-1.5 w-1.5 rounded-full ${r.agreement ? "bg-success" : "bg-warning"}`} />
                  <span className="text-muted-foreground">{r.report_id}</span>
                  <span className="text-foreground">
                    {r.ai_subtype ?? "None"} → <span className="text-primary">{r.confirmed_subtype}</span>
                  </span>
                </span>
                <span className="text-muted-foreground">{r.clinician_name}</span>
              </li>
            ))}
          </ul>
        </div>
      )}
    </div>
  );
}
