// Hybrid clinical decision system for leukemia risk.
// Combines a 2-layer ANN with WHO/NCCN-aligned hematology rules so that
// the final output mirrors a hematologist's bedside reasoning.
// Educational demo — NOT a medical device.

export interface AnnInputs {
  wbc: number;        // ×10^9/L  normal 4–11
  rbc: number;        // ×10^12/L normal 4.2–5.9
  hemoglobin: number; // g/dL     normal 12–17
  platelets: number;  // ×10^9/L  normal 150–400
  blastPct: number;   // % blasts in peripheral blood / marrow
  age: number;        // years
}

const tanh = (x: number) => Math.tanh(x);
const sigmoid = (x: number) => 1 / (1 + Math.exp(-x));

function normalize(x: AnnInputs): number[] {
  return [
    (x.wbc - 7.5) / 20,
    (x.rbc - 5) / 2,
    (x.hemoglobin - 14) / 5,
    (x.platelets - 275) / 200,
    (x.blastPct - 5) / 30,
    (x.age - 40) / 40,
  ];
}

const W1: number[][] = [
  [ 1.8, -0.6, -1.4, -1.2,  2.6,  0.4],
  [ 2.2,  0.1, -0.2, -1.6,  2.0,  0.3],
  [-0.4, -1.2, -1.8, -0.8,  1.0,  0.6],
  [ 0.3,  0.0, -0.3, -0.4,  0.6,  1.2],
];
const b1 = [-0.5, -0.4, -0.3, -0.6];
const W2 = [2.4, 2.2, 1.6, 0.9];
const b2 = -1.2;

export type RiskLevel = "low" | "moderate" | "high" | "critical";

export interface ClinicalRule {
  code: string;
  text: string;
  severity: "info" | "warn" | "critical";
}

export interface AnnResult {
  risk: number;            // 0..1  final clinically-weighted risk
  annRisk: number;         // 0..1  raw network output
  level: RiskLevel;
  confidence: number;      // 0..1  agreement between ANN + rules
  impression: string;      // one-line clinician impression
  subtypeHint: string | null; // ALL / AML / CLL / CML / MDS / null
  rules: ClinicalRule[];   // triggered diagnostic rules
  contributions: { label: string; value: number }[];
  recommendation: string;
}

function runAnn(input: AnnInputs) {
  const x = normalize(input);
  const h = W1.map((row, i) => tanh(row.reduce((s, w, j) => s + w * x[j], 0) + b1[i]));
  const risk = sigmoid(W2.reduce((s, w, i) => s + w * h[i], 0) + b2);
  return { risk, h };
}

// WHO / NCCN-aligned diagnostic logic.
function applyClinicalRules(input: AnnInputs, annRisk: number) {
  const rules: ClinicalRule[] = [];
  let floor = 0;     // minimum risk forced by rules
  let boost = 0;     // additive boost
  let subtype: string | null = null;
  let impression = "Within normal hematologic parameters.";

  const { wbc, hemoglobin, platelets, blastPct, age } = input;
  const anemia = hemoglobin < 12;
  const severeAnemia = hemoglobin < 8;
  const thrombocytopenia = platelets < 150;
  const severeThrombocytopenia = platelets < 50;
  const leukopenia = wbc < 4;
  const leukocytosis = wbc > 11;
  const hyperleukocytosis = wbc > 100;
  const pancytopenia = leukopenia && anemia && thrombocytopenia;

  // 1) WHO definitive criterion: ≥20% blasts → acute leukemia
  if (blastPct >= 20) {
    floor = Math.max(floor, 0.97);
    rules.push({ code: "WHO-AL", text: `Blasts ≥ 20% — WHO criterion for acute leukemia.`, severity: "critical" });
    if (age < 18) { subtype = "ALL"; impression = "Findings diagnostic of Acute Lymphoblastic Leukemia (ALL)."; }
    else if (age >= 60) { subtype = "AML"; impression = "Findings diagnostic of Acute Myeloid Leukemia (AML)."; }
    else { subtype = "AML / ALL"; impression = "Acute leukemia — immunophenotyping required to distinguish AML vs ALL."; }
  } else if (blastPct >= 10) {
    boost += 0.35;
    rules.push({ code: "MDS-EB2", text: `Blasts ${blastPct}% — high-grade MDS / impending acute leukemia.`, severity: "critical" });
    subtype = subtype ?? "MDS-EB";
    impression = "High-grade myelodysplastic syndrome with excess blasts.";
  } else if (blastPct >= 5) {
    boost += 0.18;
    rules.push({ code: "MDS-EB1", text: `Blasts ${blastPct}% — MDS with excess blasts (5–9%).`, severity: "warn" });
    subtype = subtype ?? "MDS";
  }

  // 2) Hyperleukocytosis patterns
  if (hyperleukocytosis && blastPct < 5 && age >= 55) {
    floor = Math.max(floor, 0.85);
    rules.push({ code: "CLL", text: `Lymphocytosis with WBC > 100 in older adult — suspicious for CLL.`, severity: "critical" });
    subtype = subtype ?? "CLL";
    impression = impression === "Within normal hematologic parameters." ? "Pattern consistent with Chronic Lymphocytic Leukemia (CLL)." : impression;
  } else if (wbc > 50 && blastPct < 10 && age >= 25 && age <= 65) {
    floor = Math.max(floor, 0.8);
    rules.push({ code: "CML", text: `Marked leukocytosis with low blasts — suspect Chronic Myeloid Leukemia.`, severity: "critical" });
    subtype = subtype ?? "CML";
    impression = impression === "Within normal hematologic parameters." ? "Pattern consistent with Chronic Myeloid Leukemia (CML); BCR-ABL testing indicated." : impression;
  } else if (leukocytosis) {
    boost += 0.08;
    rules.push({ code: "LEUK", text: `Leukocytosis (WBC ${wbc}). Reactive vs neoplastic — correlate with smear.`, severity: "warn" });
  }

  // 3) Cytopenias
  if (pancytopenia) {
    boost += 0.25;
    rules.push({ code: "PANCYTO", text: `Pancytopenia — marrow infiltration or failure must be excluded.`, severity: "critical" });
    if (blastPct >= 1) floor = Math.max(floor, 0.7);
  } else {
    if (severeAnemia)       { boost += 0.15; rules.push({ code: "ANEM-S", text: `Severe anemia (Hb ${hemoglobin}).`, severity: "warn" }); }
    else if (anemia)        { boost += 0.06; rules.push({ code: "ANEM",   text: `Mild–moderate anemia (Hb ${hemoglobin}).`, severity: "info" }); }
    if (severeThrombocytopenia) { boost += 0.15; rules.push({ code: "THR-S",  text: `Severe thrombocytopenia (Plt ${platelets}) — bleeding risk.`, severity: "warn" }); }
    else if (thrombocytopenia)  { boost += 0.05; rules.push({ code: "THR",    text: `Thrombocytopenia (Plt ${platelets}).`, severity: "info" }); }
    if (leukopenia)         { boost += 0.05; rules.push({ code: "LKP",    text: `Leukopenia (WBC ${wbc}) — infection risk.`, severity: "info" }); }
  }

  // 4) Age factor (mild)
  if (age >= 65) boost += 0.03;

  if (rules.length === 0) {
    rules.push({ code: "NORM", text: "Complete blood count within reference ranges.", severity: "info" });
  }

  // Final clinically-weighted risk: blend ANN with rules, then enforce floor.
  let risk = Math.min(1, annRisk * 0.55 + boost + (floor > 0 ? floor * 0.45 : 0));
  if (floor > 0) risk = Math.max(risk, floor);
  risk = Math.max(0, Math.min(1, risk));

  return { risk, rules, subtype, impression };
}

export function predictLeukemia(input: AnnInputs): AnnResult {
  const { risk: annRisk, h } = runAnn(input);
  const { risk, rules, subtype, impression } = applyClinicalRules(input, annRisk);

  const level: RiskLevel =
    risk >= 0.85 ? "critical" :
    risk >= 0.6  ? "high"     :
    risk >= 0.33 ? "moderate" : "low";

  // Confidence = 1 − |ANN − rule-based risk|  (agreement)
  const confidence = 1 - Math.abs(annRisk - risk);

  const labels = ["Cytopenia + blasts", "Leukocytosis pattern", "Anemia signal", "Age factor"];
  const contributions = h.map((v, i) => ({
    label: labels[i],
    value: Math.max(0, Math.min(1, (v * W2[i] + 2) / 4)),
  }));

  const recommendation =
    level === "critical" ? "Urgent hematology referral, peripheral smear review, flow cytometry & bone marrow biopsy."
    : level === "high"   ? "Hematology consult within 48 h; repeat CBC with smear and reticulocyte count."
    : level === "moderate" ? "Repeat CBC in 1–2 weeks and review peripheral smear; correlate clinically."
    : "Routine follow-up. No acute hematologic concern.";

  return { risk, annRisk, level, confidence, impression, subtypeHint: subtype, rules, contributions, recommendation };
}
