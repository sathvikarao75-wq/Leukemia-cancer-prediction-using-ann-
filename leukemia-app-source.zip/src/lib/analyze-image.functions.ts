import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";

const analyzeSchema = z.object({
  imageDataUrl: z.string().min(20).max(8_000_000),
  bloodGroup: z.string().max(8).optional(),
  notes: z.string().max(400).optional(),
});

export interface ImageFinding {
  summary: string;
  riskBoost: number; // -1..1 shift to apply to ANN risk
  observations: string[];
  recommendation: string;
}

export const analyzeMedicalImage = createServerFn({ method: "POST" })
  .inputValidator((d) => analyzeSchema.parse(d))
  .handler(async ({ data }): Promise<ImageFinding> => {
    const apiKey = process.env.LOVABLE_API_KEY;
    if (!apiKey) throw new Error("AI Gateway not configured");

    const system = `You are a senior hematopathology assistant at a super-speciality oncology hospital. You analyze patient-submitted images (skin wound, bruising, petechiae, blood smear, or general clinical photo) for leukemia-relevant visual indicators only.

Look for: petechiae, purpura, unusual bruising patterns, pallor, non-healing wounds, gum bleeding, abnormal blood-smear morphology (immature blasts, hypogranular cells), or signs of cytopenia.

Respond ONLY with strict JSON matching:
{
 "summary": "one short clinical sentence",
 "riskBoost": <number between -0.3 and 0.4>,
 "observations": ["finding 1", "finding 2", "..."],
 "recommendation": "one sentence clinical next-step"
}

If the image is not medically interpretable (blurry, unrelated, e.g. a landscape), return riskBoost 0 and explain in summary.`;

    const userText = `Blood group: ${data.bloodGroup || "Unknown"}. Additional notes: ${data.notes || "none"}. Analyze the attached image for leukemia-relevant visual signs.`;

    const res = await fetch("https://ai.gateway.lovable.dev/v1/chat/completions", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${apiKey}`,
      },
      body: JSON.stringify({
        model: "google/gemini-2.5-flash",
        messages: [
          { role: "system", content: system },
          {
            role: "user",
            content: [
              { type: "text", text: userText },
              { type: "image_url", image_url: { url: data.imageDataUrl } },
            ],
          },
        ],
        response_format: { type: "json_object" },
      }),
    });

    if (!res.ok) {
      const text = await res.text();
      if (res.status === 429) throw new Error("Rate limit reached. Please wait a moment.");
      if (res.status === 402) throw new Error("AI credits exhausted. Add credits in Workspace settings.");
      throw new Error(`AI analysis failed: ${text.slice(0, 200)}`);
    }

    const json = await res.json();
    const content: string = json.choices?.[0]?.message?.content ?? "{}";
    let parsed: ImageFinding;
    try {
      parsed = JSON.parse(content);
    } catch {
      parsed = {
        summary: "Could not interpret image.",
        riskBoost: 0,
        observations: [content.slice(0, 200)],
        recommendation: "Please upload a clearer clinical photograph.",
      };
    }
    parsed.riskBoost = Math.max(-0.3, Math.min(0.4, Number(parsed.riskBoost) || 0));
    return parsed;
  });
