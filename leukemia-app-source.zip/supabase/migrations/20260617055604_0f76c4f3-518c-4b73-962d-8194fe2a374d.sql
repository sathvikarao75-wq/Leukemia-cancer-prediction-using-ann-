CREATE TABLE public.clinician_reviews (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  report_id TEXT NOT NULL,
  patient_name TEXT,
  patient_age INTEGER,
  blood_group TEXT,
  wbc NUMERIC, rbc NUMERIC, hemoglobin NUMERIC, platelets NUMERIC, blast_pct NUMERIC,
  ai_risk NUMERIC NOT NULL,
  ai_level TEXT NOT NULL,
  ai_subtype TEXT,
  confirmed_subtype TEXT NOT NULL,
  agreement BOOLEAN NOT NULL,
  clinician_name TEXT NOT NULL,
  notes TEXT,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

GRANT SELECT, INSERT ON public.clinician_reviews TO anon, authenticated;
GRANT ALL ON public.clinician_reviews TO service_role;

ALTER TABLE public.clinician_reviews ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Anyone can read reviews" ON public.clinician_reviews FOR SELECT USING (true);
CREATE POLICY "Anyone can submit reviews" ON public.clinician_reviews FOR INSERT WITH CHECK (true);

CREATE INDEX clinician_reviews_created_at_idx ON public.clinician_reviews (created_at DESC);